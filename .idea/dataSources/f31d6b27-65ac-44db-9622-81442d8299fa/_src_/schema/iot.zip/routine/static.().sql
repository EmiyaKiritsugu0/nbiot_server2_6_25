CREATE PROCEDURE static()
  begin 
DECLARE dFC double ;
DECLARE dDS double ;
DECLARE dT  time;
declare flagnum int;
declare idnum int;
declare i int;
declare j int;
set i = 1;
set j = 0;
set dT = '00:00:00';
  select count(distinct(iotDeviceId)) from t_ddi into idnum;
repeat 
  select sum(if(iotDeviceId = concat(i,'') and informationDate = '2018-3-16' and deltaFuel > 0, deltaFuel,0)) from t_ddi  into dFC;
  select sum(if(iotDeviceId = CONCAT(i,'') and informationDate = '2018-3-16' and deltaDistanceSum > 10,deltaDistanceSum,0)) from t_ddi into dDS;
  select sum(if(iotDeviceId = CONCAT(i,'') and informationDate = '2018-3-16' and workingFlag = true, 1 ,0)) from t_ddi into flagnum ;

  
  while j < flagnum do 
  set dT =  time(date_add(CONCAT('2000-01-01',' ',dT),interval 8 hour));
  set j = j + 1;
  end while; 
 

   INSERT INTO t_si(
        iotDeviceId ,currentDate ,
        dailyFuelCost,
        dailyDistance,dailyRunTime,
        dailyUsingRate
        )
        VALUES          (
        CONCAT('罐车',i), '2018-3-16',
        dFC,
        dDS,
        dT,
        (UNIX_TIMESTAMP( CONCAT(curdate(),' ',dT)) - UNIX_TIMESTAMP( CONCAT(curdate(),' ','00:00:00'))) /(UNIX_TIMESTAMP( CONCAT(curdate(),' ','23:59:59')) - UNIX_TIMESTAMP( CONCAT(curdate(),' ','00:00:00'))) 
        );
    set dT = '00:00:00';
    set i = i + 1;
until i >  idnum

end repeat;


end;
