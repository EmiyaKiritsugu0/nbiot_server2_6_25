CREATE PROCEDURE cursor_test()
  BEGIN

  
     declare aa VARCHAR(255) ;
     declare bb Time;
     declare cc Date;
     declare dd double;

  
  DECLARE done INT DEFAULT FALSE;


  
  declare mycursor cursor for
   select 
       r1.iotDeviceId,
       r1.informationTime,
       r1.informationDate,
       - r1.containingFuel + r2.containingFuel
  from(
   select      t_ddi.iotDeviceId,
               t_ddi.informationTime,
               t_ddi.informationDate,
               t_ddi.containingFuel
          from t_ddi
         order by t_ddi.iotDeviceId) r1
  left join (
   select      t_ddi.iotDeviceId,
               t_ddi.informationTime,
               t_ddi.informationDate,
               t_ddi.containingFuel
          from t_ddi
         order by t_ddi.iotDeviceId) r2
    on r1.iotDeviceId = r2.iotDeviceId 
         and r1.informationTime = time(date_add(concat(r2.informationDate,' ',r2.informationTime),interval 8 hour))
         and r1.informationDate = date(date_add(concat(r2.informationDate,' ',r2.informationTime),interval 8 hour)) ;

  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;


  
  OPEN mycursor ;
  
  
  read_loop: LOOP
    
    FETCH mycursor INTO   aa,bb,cc,dd;
    
    IF done THEN
      LEAVE read_loop;
    END IF;
    

     update  t_ddi set deltaFuel =  ifnull(dd,0) where iotDeviceId = aa and informationTime = bb and informationDate = cc;

     
  END LOOP;
  
  CLOSE mycursor ;

END;
